#!/usr/bin/env Rscript
# Extract real, unmodified records for the downloadable rs12470189 example.
# Usage: Rscript prepare-lcl-subset.R [project_root] [output_directory]
suppressPackageStartupMessages({library(Rsamtools); library(GenomicRanges)})
args <- commandArgs(trailingOnly = TRUE)
project <- if (length(args)) args[1] else '/project/spott/cshan/fiber-seq'
out <- if (length(args) >= 2L) args[2] else 'lcl-autocorrelation-example'
if (file.exists(out)) stop('Choose a new output directory')
dir.create(out, recursive = TRUE)
region_id <- 'rank01_rs12470189_chr2_119290945_119291178'
run <- file.path(project, 'LCL_project/auto_correlation/resolution04')
selection_path <- file.path(run,'inputs/selection_signature.rds')
input_path <- file.path(run,'inputs',region_id,'m6a_input.rds')
report_path <- file.path(run,'outputs',region_id,'report_data.rds')
selection <- readRDS(selection_path)
input <- readRDS(input_path)
report <- readRDS(report_path)
r <- report$region
cohort <- c('AL16_bc2114_18508', 'AL30_bc2179_18510')
sm <- selection$sample_table[match(cohort,selection$sample_table$sample_name),]
stopifnot(!anyNA(sm$sample_name), !anyDuplicated(sm$sample_name),
    identical(input$records$row_id,rownames(input$binary)),
    identical(input$records$row_id,report$row_ids))
keep <- which(input$records$sample_name %in% cohort)
records <- input$records[keep,,drop=FALSE]
query <- GRanges(r$chr, IRanges(r$analysis_start,r$analysis_end))
write_tsv <- function(x, name) write.table(x,file.path(out,name),sep='\t',
    quote=FALSE,row.names=FALSE,na='NA')
manifest <- list()
for (j in seq_len(nrow(sm))) {
    sample <- sm$sample_name[j]
    bed_source <- file.path(sm$fire_dir[j],'extracted_results/m6a_by_chr',
        paste0(sample,'.ft_extracted_m6a.',r$chr,'.bed.gz'))
    lines <- scanTabix(bed_source,param=query)[[1]]
    fields <- strsplit(lines,'\t',fixed=TRUE)
    ids <- vapply(fields,`[`,character(1),4L)
    wanted <- records$original_RID[records$sample_name==sample]
    selected <- which(ids %in% wanted)
    # Preserve exact original BED12 lines; keep the original longest alignment rule.
    starts <- as.integer(vapply(fields[selected],`[`,character(1),2L))
    ends <- as.integer(vapply(fields[selected],`[`,character(1),3L))
    ord <- order(ids[selected],-(ends-starts))
    selected <- selected[ord][!duplicated(ids[selected][ord])]
    starts <- as.integer(vapply(fields[selected],`[`,character(1),2L))
    ends <- as.integer(vapply(fields[selected],`[`,character(1),3L))
    stopifnot(setequal(ids[selected],wanted),all(starts<r$analysis_start),all(ends>=r$analysis_end))
    selected <- selected[order(starts,ends,ids[selected])]
    bed <- file.path(out,paste0(sample,'.m6a.bed'))
    writeLines(lines[selected],bed)
    gz <- bgzip(bed,dest=paste0(bed,'.gz')); indexTabix(gz,format='bed'); unlink(bed)

    vcf_source <- file.path('/project/spott/1_Shared_projects/LCL_Fiber_seq/preprocess_final_merged_samples',
        sample,paste0(sample,'.5mC.6mA.aligned.phased.vcf.gz'))
    header <- headerTabix(vcf_source)$header
    column_header <- header[startsWith(header,'#CHROM\t')]
    columns <- strsplit(column_header,'\t',fixed=TRUE)[[1]]
    sample_col <- match(sm$cell_line[j],columns)
    stopifnot(length(sample_col)==1L,!is.na(sample_col),sample_col>=10L)
    vcf_lines <- scanTabix(vcf_source,param=query)[[1]]
    variants <- strsplit(vcf_lines,'\t',fixed=TRUE)
    variants <- variants[vapply(variants,function(f)
        as.integer(f[2])>=r$analysis_start && as.integer(f[2])<=r$analysis_end,logical(1))]
    selected_columns <- c(seq_len(9L),sample_col)
    subset_lines <- vapply(variants,function(f) paste(f[selected_columns],collapse='\t'),character(1))
    # Preserve original INFO fields (including cohort AF); they are not recomputed.
    vcf <- file.path(out,paste0(sample,'.region.vcf'))
    writeLines(c(header[startsWith(header,'##')],
        paste(columns[selected_columns],collapse='\t'),subset_lines),vcf)
    vg <- bgzip(vcf,dest=paste0(vcf,'.gz')); indexTabix(vg,format='vcf'); unlink(vcf)
    focal <- variants[vapply(variants,function(f) as.integer(f[2])==r$focal_pos &&
        f[4]==r$ref && f[5]==r$alt,logical(1))]
    stopifnot(length(focal)==1L)
    f <- focal[[1]]
    gt <- setNames(strsplit(f[sample_col],':',fixed=TRUE)[[1]],strsplit(f[9],':',fixed=TRUE)[[1]])
    meta <- records[records$sample_name==sample,]
    stopifnot(all(meta$focal_genotype==gt[['GT']]),all(as.character(meta$phase_set)==gt[['PS']]))
    info <- file.info(c(bed_source,vcf_source))
    manifest[[j]] <- data.frame(sample_name=sample,cell_line=sm$cell_line[j],
        source=c(bed_source,vcf_source),source_bytes=info$size,
        source_mtime_utc=format(info$mtime,tz='UTC',usetz=TRUE),
        extracted_file=c(basename(gz),basename(vg)),
        retained_records=c(length(selected),length(variants)))
}
write_tsv(data.frame(sample_name=sm$sample_name,sample_label=sub('_.*','',sm$sample_name),
    m6a=paste0(sm$sample_name,'.m6a.bed.gz'),m6a_format='bed12_fibertools',
    vcf=paste0(sm$sample_name,'.region.vcf.gz'),vcf_sample=sm$cell_line),'samples.tsv')
write_tsv(data.frame(chr=r$chr,start=r$analysis_start-1L,end=r$analysis_end,region_id=r$region_id,
    focal_snp=r$focal_snp,focal_pos=r$focal_pos,ref=r$ref,alt=r$alt),'regions.tsv')
write_tsv(records[,c('sample_name','original_RID','row_id','haplotype','phase_set',
    'focal_genotype','allele_label','allele_status','phase_source')],'read_phasing.tsv')
write_tsv(do.call(rbind,manifest),'provenance.tsv')
write_tsv(data.frame(file=c(selection_path,input_path,report_path),
    md5=unname(tools::md5sum(c(selection_path,input_path,report_path)))),'source_checksums.tsv')
saveRDS(list(region=r[,c('region_id','chr','analysis_start','analysis_end','focal_pos','focal_snp','ref','alt')],
    row_ids=records$row_id,binary=input$binary[keep,,drop=FALSE],acf=report$acf[keep,,drop=FALSE],
    params=report$params),file.path(out,'reference.rds'),compress='xz')
writeLines(c('Real LCL subset: rs12470189, chr2:119290056-119292055 (one-based inclusive).',
    paste('Libraries:',paste(cohort,collapse=', ')),paste('Retained molecules:',nrow(records)),
    'All retained phased reads from these libraries in the saved resolution04 ACF input.',
    'No downsampling by ACF, clustering, peak strength or allele was performed.',
    'BED12 alignment records are copied verbatim; full alignment boundaries and calls are retained.',
    'Analysis is limited to the 2000-bp window specified in regions.tsv.',
    'Each VCF retains all regional records but only the matching cell-line genotype column.',
    'Original fixed VCF fields, FORMAT and genotype/PS values are preserved.',
    'INFO annotations, including AF, describe the original source cohort, not this subset.',
    'VCF alone does not assign haplotypes to reads. read_phasing.tsv contains the saved read-level assignments.',
    'reference.rds contains the matching original binary inputs and per-read ACFs, not cluster labels.',
    'provenance.tsv records original file locations/statistics; source_checksums.tsv records saved-run hashes.',
    'prepare-lcl-subset.R documents extraction and requires access to the original project files.',
    'The tutorial itself needs only this archive and the installed R packages.',
    'These are existing biological data. No new data license is asserted by this example.'),
    file.path(out,'README.txt'))
script <- sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
stopifnot(file.copy(script,file.path(out,'prepare-lcl-subset.R')))
files <- list.files(out,full.names=TRUE)
write_tsv(data.frame(file=basename(files),md5=unname(tools::md5sum(files))),'checksums.tsv')
# Store only a single relative directory in the portable archive.
old <- setwd(dirname(normalizePath(out)))
utils::zip(paste0(basename(out),'.zip'),list.files(basename(out),full.names=TRUE))
setwd(old)
cat('Created',nrow(records),'real reads in',out,'\n')
