Real LCL subset: rs12470189, chr2:119290056-119292055 (one-based inclusive).
Libraries: AL16_bc2114_18508, AL30_bc2179_18510
Retained molecules: 33
All retained phased reads from these libraries in the saved resolution04 ACF input.
No downsampling by ACF, clustering, peak strength or allele was performed.
BED12 alignment records are copied verbatim; full alignment boundaries and calls are retained.
Analysis is limited to the 2000-bp window specified in regions.tsv.
Each VCF retains all regional records but only the matching cell-line genotype column.
Original fixed VCF fields, FORMAT and genotype/PS values are preserved.
INFO annotations, including AF, describe the original source cohort, not this subset.
VCF alone does not assign haplotypes to reads. read_phasing.tsv contains the saved read-level assignments.
reference.rds contains the matching original binary inputs and per-read ACFs, not cluster labels.
provenance.tsv records original file locations/statistics; source_checksums.tsv records saved-run hashes.
prepare-lcl-subset.R documents extraction and requires access to the original project files.
The tutorial itself needs only this archive and the installed R packages.
These are existing biological data. No new data license is asserted by this example.
