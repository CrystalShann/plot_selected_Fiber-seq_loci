# Recreate the downloadable synthetic dataset; only Rsamtools is required.
# Run from the directory where synthetic-autocorrelation/ should be created.
set.seed(20261103)
out <- 'synthetic-autocorrelation'
if (dir.exists(out)) stop('Choose a directory without an existing synthetic-autocorrelation folder')
dir.create(out)
truth <- list()
for (s in c('synthetic_A','synthetic_B')) {
  rows <- list()
  for (j in 1:25) {
    period <- if (j <= 12) 180L else if (j <= 24) 220L else NA_integer_
    rid <- sprintf('%s_read%02d',s,j)
    calls <- integer()
    if (!is.na(period)) {
      centers <- seq(sample(25:160,1),2000,by=period)
      # Narrow accessible patches recur at a known spacing; add sparse noise.
      calls <- unlist(lapply(centers,function(z) z + sample(-9:9,9) + sample(-2:2,1)))
      calls <- sort(unique(c(calls,sample(1:2000,12))))
      calls <- calls[calls >= 1 & calls <= 2000]
    }
    # BED [900,3100) spans analysis [1000,3000); boundary blocks are sentinels.
    offsets <- c(0L, 100L + calls - 1L, 2199L)
    rows[[j]] <- data.frame(chr='chrSynthetic',start=900L,end=3100L,RID=rid,
      score=1000,strand='+',thickStart=900L,thickEnd=3100L,itemRgb='0,0,0',
      blockCount=length(offsets),blockSizes=paste(rep(1L,length(offsets)),collapse=','),
      blockStarts=paste(offsets,collapse=','))
    truth[[length(truth)+1L]] <- data.frame(sample_name=s,original_RID=rid,
      truth=if(is.na(period)) 'zero_call' else paste0('period_',period),period_bp=period,
      n_calls=length(calls))
  }
  bed <- file.path(out,paste0(s,'.m6a.bed'))
  write.table(do.call(rbind,rows),bed,sep='\t',quote=FALSE,row.names=FALSE,col.names=FALSE)
  gz <- Rsamtools::bgzip(bed, dest = paste0(bed, ".gz"), overwrite=TRUE)
  Rsamtools::indexTabix(gz,format='bed')
  unlink(bed)
}
write.table(data.frame(sample_name=c('synthetic_A','synthetic_B'),
  sample_label=c('Synthetic A','Synthetic B'),m6a=paste0(c('synthetic_A','synthetic_B'),'.m6a.bed.gz'),
  m6a_format='bed12_fibertools'),file.path(out,'samples.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
write.table(data.frame(chr='chrSynthetic',start=1000L,end=3000L,region_id='synthetic_periodicity'),
  file.path(out,'regions.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
write.table(do.call(rbind,truth),file.path(out,'truth.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
writeLines(c('Entirely synthetic demonstration data; no biological samples.',
  'Seed: 20261103. 2 libraries, 25 reads each; 24 reads per library have planted',
  '180/220-bp spacing, and 1 per library has no m6A calls. Both libraries contain',
  'both periodicities; sample identity is not the planted class.',
  'chrSynthetic:1001-3000 (1-based), equivalently BED chrSynthetic 1000 3000.',
  'BED12 files are bgzip-compressed and tabix-indexed. Paths in samples.tsv are relative.',
  'truth.tsv is for validation only and is never used as an analysis input.',
  'These simplified recurring patches illustrate ACF, not a calibrated biological model.',
  'Use freely under CC0-1.0. See generate-synthetic.R for deterministic regeneration.'),
  file.path(out,'README.txt'))
file.copy('generate-synthetic.R',file.path(out,'generate-synthetic.R'))
files <- list.files(out,full.names=TRUE)
write.table(data.frame(file=basename(files),md5=unname(tools::md5sum(files))),
  file.path(out,'checksums.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
utils::zip('synthetic-autocorrelation.zip',list.files(out,full.names=TRUE))
