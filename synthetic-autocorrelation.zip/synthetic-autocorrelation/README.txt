Entirely synthetic demonstration data; no biological samples.
Seed: 20261103. 2 libraries, 25 reads each; 24 reads per library have planted
180/220-bp spacing, and 1 per library has no m6A calls. Both libraries contain
both periodicities; sample identity is not the planted class.
chrSynthetic:1001-3000 (1-based), equivalently BED chrSynthetic 1000 3000.
BED12 files are bgzip-compressed and tabix-indexed. Paths in samples.tsv are relative.
truth.tsv is for validation only and is never used as an analysis input.
These simplified recurring patches illustrate ACF, not a calibrated biological model.
Use freely under CC0-1.0. See generate-synthetic.R for deterministic regeneration.
